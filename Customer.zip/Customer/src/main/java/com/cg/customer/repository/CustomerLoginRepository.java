package com.cg.customer.repository;
import org.springframework.data.jpa.repository.JpaRepository;


import com.cg.customer.bean.CustomerLogin;

public interface CustomerLoginRepository extends JpaRepository<CustomerLogin, String> {

}
