package com.cg.customer.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.cg.customer.bean.WishList;;
public interface WishListRepository extends JpaRepository<WishList,Long>{

}
