package com.cg.customer.service;

import java.util.List;

import com.cg.customer.bean.CustomerEntity;
import com.cg.customer.bean.Product;

public interface IProductService {
	
	public String login(String email, String password);
	public List<Product> displayAllProduct();
	public CustomerEntity insertCustomer(CustomerEntity customer) ;
}
