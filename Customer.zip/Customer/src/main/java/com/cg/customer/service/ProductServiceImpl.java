package com.cg.customer.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.customer.bean.CustomerEntity;
import com.cg.customer.bean.CustomerLogin;
import com.cg.customer.bean.Product;
import com.cg.customer.bean.WishList;
import com.cg.customer.repository.CustomerEntityRepository;
import com.cg.customer.repository.CustomerLoginRepository;
import com.cg.customer.repository.ProductRepository;
import com.cg.customer.repository.WishListRepository;

@Service
@Transactional
public class ProductServiceImpl implements IProductService {
	@Autowired
	ProductRepository productrepo;

	@Autowired
	CustomerLoginRepository loginrepo;

	@Autowired
	CustomerEntityRepository entityrepo;

	@Autowired
	WishListRepository wishRepo;

	@Override
	public List<Product> displayAllProduct() {
		// TODO Auto-generated method stub
		List<Product> list = new ArrayList();
		list = productrepo.findAll();
		return list;
	}

	@Override
	public String login(String email, String password) {
		Optional<CustomerLogin> opt = loginrepo.findById(email);
		if (opt.isPresent()) {
			CustomerLogin login = opt.get();
			System.out.println(login.getEmail());
			if (login.getPassword().equals(password)) {
				System.out.println("Successful");
				return "Login Successful";
			} else {
				System.out.println("Failure");
				return "Login Failed";
			}
		} else {
			return "Login Failed";
		}
	}

	@Override
	public CustomerEntity insertCustomer(CustomerEntity customer) {

		CustomerEntity entity = new CustomerEntity();

		// password encrypt and decrypt
		String password = customer.getPassword();
		// String passwordEnc = SecurePassword.encrypt(password);
		// String passwordDec = SecurePassword.decrypt(passwordEnc);

		// System.out.println("Encrypted Text : " + passwordEnc);
		// System.out.println("Decrypted Text : " + passwordDec);
		// user.setPassword(passwordEnc);
		entity.setName(customer.getName());
		entity.setEmail(customer.getEmail());
		entity.setAddress(customer.getAddress());
		entity.setMobileNo(customer.getMobileNo());
		entity.setPassword(customer.getPassword());
		return entityrepo.saveAndFlush(customer);

	}

	@Override
	public WishList addToWishList(Long prodId) {
		WishList entity = new WishList();
		List<WishList> wlist = wishRepo.findAll();
		entity.setProdId(prodId);
		return wishRepo.saveAndFlush(entity);

	}

	@Override
	public List<WishList> displayProduct() {

		List<WishList> wlist = wishRepo.findAll();

		List<WishList> list = new ArrayList();
		System.out.println(list.get(1).getProd_Name());
		for (WishList wishList : list) {
			WishList wishlist = new WishList();
			wishlist.getProdId();
			wishlist.getWishlistId();
			wishlist.getProd_Name();
			wlist.add(wishlist);
		}
		return wlist;

	}

	
}
