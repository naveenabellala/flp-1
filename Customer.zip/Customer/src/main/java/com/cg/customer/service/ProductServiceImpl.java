package com.cg.customer.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.customer.bean.CustomerEntity;
import com.cg.customer.bean.CustomerLogin;
import com.cg.customer.bean.Product;
import com.cg.customer.repository.CustomerEntityRepository;
import com.cg.customer.repository.CustomerLoginRepository;
import com.cg.customer.repository.ProductRepository;

@Service
@Transactional
public class ProductServiceImpl implements IProductService {
	@Autowired
	ProductRepository productrepo;
	
	@Autowired
	CustomerLoginRepository loginrepo;
	
	@Autowired
	CustomerEntityRepository entityrepo;

	@Override
	public List<Product> displayAllProduct() {
		// TODO Auto-generated method stub
		List<Product>list = new ArrayList();
		list=productrepo.findAll();
		return list;
	}

	@Override
	public String login(String email, String password) {
		Optional<CustomerLogin> opt = loginrepo.findById(email);
		if (opt.isPresent()) {
			CustomerLogin login = opt.get();
			if (login.getPassword().equals(password)) {
				System.out.println("Successful");
				return "Login Successful";
			} else {
				System.out.println("Failure");
				return "Login Failed";
			}
		}
		else {
			return "Login Failed";
		}
	}

	@Override
	public CustomerEntity insertCustomer(CustomerEntity customer) {
		
		entityrepo.save(customer);
		return customer;
		
	}
	
	

	
}

