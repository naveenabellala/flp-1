package com.cg.customer.bean;

public class CartList {
	private Long prodId;
	private long cardId;
	private String prod_Name;
	private Double prod_Price;
	private Long prod_Quantity;
	private Integer prod_Discount;
	private String prod_Category;
	private String prod_Desc;
	private String prod_Image;
	
	
}
