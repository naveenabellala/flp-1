import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DisplayproductsComponent } from './displayproducts/displayproducts.component'
import { CustomersignupComponent } from './customersignup/customersignup.component'
const routes: Routes = [
  {
    path : 'displayproducts',
    component : DisplayproductsComponent
  }
  ,
  {
    path : '',
    component : CustomersignupComponent
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
