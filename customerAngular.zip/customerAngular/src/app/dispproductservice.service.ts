import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { Observable } from '../../node_modules/rxjs';
@Injectable({
  providedIn: 'root'
})
export class DispproductserviceService {

  private baseUrl='http://localhost:3456';
  constructor(private http:HttpClient) { }


  public customerlogin(admin):Observable<String>{
    return this.http.get(`${this.baseUrl}/login/${admin.email}/${admin.password}`,{responseType:"text"});
  }
  public displayproducts():Observable<any>
  {
    return this.http.get(`${this.baseUrl}/login/`)
  }

  public addCustomer(user):Observable<any>{
    return this.http.post(`${this.baseUrl}`+`/customer`,user,{responseType : 'json'})
  }
}
