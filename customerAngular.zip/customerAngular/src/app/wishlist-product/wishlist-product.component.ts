import { Component, OnInit } from '@angular/core';
import {DispproductserviceService} from'../dispproductservice.service'

@Component({
  selector: 'app-wishlist-product',
  templateUrl: './wishlist-product.component.html',
  styleUrls: ['./wishlist-product.component.css']
})
export class WishlistProductComponent implements OnInit {
  results:any
  submitted:any
  constructor(private service: DispproductserviceService ) { }

  ngOnInit() {
  }
  displaywishlist(prod_id)
  {
    this.service.displayproducts().subscribe(data => {
      this.results = data;
      this.submitted = true;
    });
  }



}
