import { Component, OnInit } from '@angular/core';
import {DispproductserviceService} from '../dispproductservice.service'
@Component({
  selector: 'app-customersignup',
  templateUrl: './customersignup.component.html',
  styleUrls: ['./customersignup.component.css']
})
export class CustomersignupComponent implements OnInit {
result:any
  constructor(private service: DispproductserviceService) { }

  ngOnInit() {
  }


  createAccount(user)
  {

    console.log(user.name)
    console.log(user.choice)
    this.service.addCustomer(user).subscribe(data => {

    });
  }


}
