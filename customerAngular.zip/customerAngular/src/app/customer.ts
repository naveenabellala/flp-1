export class Customer {
    name : string;
    email : string;
    mobile_no : string;
    address : string;
    createpassword : string;  
    confirmpassword:any
}
