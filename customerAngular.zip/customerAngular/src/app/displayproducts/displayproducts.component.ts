import { Component, OnInit } from '@angular/core';
import { DispproductserviceService } from '../dispproductservice.service'
@Component({
  selector: 'app-displayproducts',
  templateUrl: './displayproducts.component.html',
  styleUrls: ['./displayproducts.component.css']
})
export class DisplayproductsComponent implements OnInit {
  result: any
  submitted = false;
  constructor(private service: DispproductserviceService) { }

  ngOnInit() {
    this.printTransaction()
  }

  printTransaction(): void {
    this.service.displayproducts().subscribe(data => {
      this.result = data;
      this.submitted = true;

      console.log(this.result);
    });
  }

}
