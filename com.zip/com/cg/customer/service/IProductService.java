package com.cg.customer.service;

import java.util.List;

//import com.cg.customer.bean.CartList;
import com.cg.customer.bean.CustomerEntity;
import com.cg.customer.bean.Product;
import com.cg.customer.bean.WishList;

public interface IProductService {
	
	//public String loginCustomer(String email, String password);
	public List<Product> displayAllProduct();
	public CustomerEntity insertCustomer(CustomerEntity customer) ;
	
	public WishList addToWishList(Long prod_Id);
	public List<WishList> displayWishlist();
	
	public String login(String email, String password);
	
	/*public CartList addToCart(Long prod_Id);
	public List<CartList> displayCartList();*/
	
}
