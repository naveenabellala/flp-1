package com.cg.customer.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.customer.bean.WishList;

@Repository
public interface WishListRepository extends JpaRepository<WishList,Long>{

	
	@Query("from WishList wish where wish.prod_Id = :prod_Id")
	WishList findByWishId(@Param("prod_Id") Long prod_Id);

}
