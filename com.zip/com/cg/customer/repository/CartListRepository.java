/*package com.cg.customer.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.customer.bean.CartList;
import com.cg.customer.bean.WishList;

@Repository
public interface CartListRepository extends JpaRepository<CartList,Long>{

	@Query("from CartList list where list.prod_Id = :prod_Id")
	WishList findByListId(@Param("prod_Id") Long prod_Id);
}
*/