package com.cg.customer.repository;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.customer.bean.CustomerEntity;
public interface CustomerLoginRepository extends JpaRepository<CustomerEntity, Long> {

	@Query("from CustomerEntity cust where cust.email = :email")
	Optional<CustomerEntity> findByEmail(@Param("email")String email);

	

}
