import { Component, OnInit } from '@angular/core';
import { DispproductserviceService } from '../dispproductservice.service';

@Component({
  selector: 'app-cartlist',
  templateUrl: './cartlist.component.html',
  styleUrls: ['./cartlist.component.css']
})
export class CartlistComponent implements OnInit {

  results:any
  submitted:any
  prod_Id : number
  constructor(private service: DispproductserviceService ) { }

  ngOnInit() {
  }

  // printTransaction(prod_Id): void {
  //   this.service.showWishlist(prod_Id).subscribe(data => {
  //     this.results = data;
  //     this.submitted = true;

  //     console.log(this.results);
  //   });
  // }

}
