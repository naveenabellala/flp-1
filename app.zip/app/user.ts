export class User {
    customerId:any;
    name:any;
    email:any;
    password:any;
    confirmpassword:any;
    address:any;
    mobileNo:any;

}
