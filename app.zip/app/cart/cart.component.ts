import { Component, OnInit } from '@angular/core';
import { DispproductserviceService } from '../dispproductservice.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  results:any
  submitted:any
  constructor(private service: DispproductserviceService ) { }

  ngOnInit() {
  }

  // displaywishlist(prod_id)
  // {
  //   this.service.addtocart(prod_id).subscribe(data => {
  //     this.results = data;
  //     this.submitted = true;
      

  //   });
  // }
}
